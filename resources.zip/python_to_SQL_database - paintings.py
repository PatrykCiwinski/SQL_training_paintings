import pandas as pd
import sqlalchemy as sql

conn_name='your connection name'
db=sql.create_engine(conn_name)
conn=db.connect()

files=['artist','canvas_size','image_link','museum','museum_hours',
'product_size','subject','work']

for file in files:
    df=pd.read_csv(f'you location on disk/{file}.csv')
    df.to_sql(file,con=conn,if_exists='replace',index=False)

